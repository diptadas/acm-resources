

/*
 * File:    hello.c 
 * Purpose: prints hello world
 * Author:  pc2@ecs.csus.edu or http://www.ecs.csus.edu/pc2
 *
 * $Id: hello.c,v 1.3 1999/10/20 04:51:23 laned Exp $
 *
 */

#include <stdio.h>

main()
{
        printf("hello world \n");
}

/* eof */
