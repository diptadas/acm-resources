
#
# File:    hello.pl
# Purpose: to print hello world
# Author:  pc2@ecs.csus.edu or http://www.ecs.csus.edu/pc2
#
# Sat Oct 30 13:44:36 PDT 1999
#
# caveat - this is not nice code, copy at own risk ;)
#
# $Id: hello.pl,v 1.3 2005/03/06 05:42:51 laned Exp $
#
#

print "hello world!\n";

# eof
