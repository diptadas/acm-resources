README

With this release there is a new up to date Administrator manual
and Team Guide.  All documentation can be found in the doc directory.
We have PDF (Acrobat), HTML (Web Page) and DOC (Word Document) versions
of all user manuals.

The latest FAQ can be found at: 
http://www.ecs.csus.edu/pc2/doc/faq/index.html

The latest documents are at:
http://www.ecs.csus.edu/pc2/pc2docs.html

The index.html in this distribution has links to these
and other documenatation for PC^2.

PC^2 Development Group
mailto:pc2@ecs.csus.edu
